#include <iostream>
#include <iomanip>
#include <cstdlib>

class Clock {
public:
    virtual void displayTime() const = 0;   // Initialize to 0
    virtual void addHour() = 0;
    virtual void addMinute() = 0;
    virtual void addSecond() = 0;
};

class Clock12 : public Clock {
private:
    int hours;   // definitions
    int minutes;
    int seconds;

public:
    Clock12() : hours(12), minutes(0), seconds(0) {}

    void displayTime() const override {   // formatting the clock
        std::cout << "12-Hour Clock: "
                  << std::setw(2) << std::setfill('0') << hours << ":"
                  << std::setw(2) << std::setfill('0') << minutes << ":"
                  << std::setw(2) << std::setfill('0') << seconds << std::endl;
    }

    void addHour() override {
        hours = (hours + 1) % 13; // 12-hour clock
    }

    void addMinute() override {
        minutes = (minutes + 1) % 60;
        if (minutes == 0) {
            addHour(); // Increase hour if minutes exceed 59
        }
    }

    void addSecond() override {
        seconds = (seconds + 1) % 60;
        if (seconds == 0) {
            addMinute(); // Increase minute if seconds exceed 59
        }
    }
};

class Clock24 : public Clock {
private:
    int hours;
    int minutes;
    int seconds;

public:
    Clock24() : hours(0), minutes(0), seconds(0) {}

    void displayTime() const override {   // formatting the 24 hour clock
        std::cout << "24-Hour Clock: "
                  << std::setw(2) << std::setfill('0') << hours << ":"
                  << std::setw(2) << std::setfill('0') << minutes << ":"
                  << std::setw(2) << std::setfill('0') << seconds << std::endl;
    }

    void addHour() override {
        hours = (hours + 1) % 24; // 24-hour clock
    }

    void addMinute() override {
        minutes = (minutes + 1) % 60;
        if (minutes == 0) {
            addHour(); // Increase hour if minutes exceed 59
        }
    }

    void addSecond() override {
        seconds = (seconds + 1) % 60;
        if (seconds == 0) {
            addMinute(); // Increase minute if seconds exceed 59
        }
    }
};

void displayMenu() {
    // Displays the menu
    std::cout << "**************************\n"
              << "*   1 - Add One Hour     *\n"
              << "*   2 - Add One Minute   *\n"
              << "*   3 - Add One Second   *\n"
              << "*   4 - Exit Program     *\n"
              << "**************************\n";
}

int getUserChoice() {
    int choice;
    std::cout << "What would you like to do? ";
    std::cin >> choice;
    return choice;
}

int main() {
    Clock12 clock12;
    Clock24 clock24;

    while (true) {
        // Display clocks
        clock12.displayTime();
        clock24.displayTime();

        // Display menu
        displayMenu();

        // Get user input
        int choice = getUserChoice();

        // Perform actions based on user input
        switch (choice) {
        case 1:
            clock12.addHour();
            clock24.addHour();
            break;
        case 2:
            clock12.addMinute();
            clock24.addMinute();
            break;
        case 3:
            clock12.addSecond();
            clock24.addSecond();
            break;
        case 4:
            std::cout << "Goodye.\n";
            exit(EXIT_SUCCESS);
        default:
            std::cout << "Can't do that. Try again.\n";
        }
    }

    return 0;   // The End
}